﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RUAN3A150.Code.DTO
{
    class UserDTO
    {
        private string _email;
        private string _senha;
        private int _id;
        public string Email { get => _email; set => _email = value; }
        public string Senha { get => _senha; set => _senha = value; }
        public int Id { get => _id; set => _id = value; }
    }
}
