﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using RUAN3A150.Code.DTO;
using RUAN3A150.Code.BLL;
using RUAN3A150.Code.DAL;

namespace RUAN3A150.Code.BLL
{
    class BrinquedoBLL
    {
            Conexao x = new Conexao();

            public void Inserir(BrinquedoDTO DTO)
            {
                string comand = $"insert into brinquedo values(null, '{DTO.Nome}', '{DTO.Valor}')";
                x.Executar(comand);
            }

            public void Alterar(BrinquedoDTO DTO)
            {
                string comand = $@"update brinquedo set nome = '{DTO.Nome}',
                                valor ='{DTO.Valor}' where id ='{DTO.Id}';";
                x.Executar(comand);
            }

            public void Excluir(BrinquedoDTO DTO)
            {
                string comand = $"delete from brinquedo where id = {DTO.Id}";
                x.Executar(comand);
            }

            public DataTable Listar()
            {
                string comand = $"select * from brinquedo order by id";
                return x.Consultar(comand);
            }
    }
}
