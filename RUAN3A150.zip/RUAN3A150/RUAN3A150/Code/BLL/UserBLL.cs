﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RUAN3A150.Code.DTO;
using RUAN3A150.Code.DAL;
using System.Data;

namespace RUAN3A150.Code.BLL
{
    class UserBLL
    {
        Conexao x = new Conexao();
        public bool Login(UserDTO user)
        {
            string query = $"select * from user where email ='{user.Email}' and senha ='{user.Senha}'";
            DataTable tabela = x.Consultar(query);

            if (tabela.Rows.Count > 0)
                return true;
            else
                return false;
        }
    }
}
