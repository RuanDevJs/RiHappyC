﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySqlConnector;

namespace RUAN3A150.Code.DAL
{
    class Conexao
    {
        MySqlConnection conexao;

        public void Conectar()
        {
            try
            {
                string query = "Persist Security Info = false; " +
                    "server = localhost; " +
                    "database = rihappy; " +
                    "uid = root; pwd=";

                conexao = new MySqlConnection(query);
                conexao.Open();
            }
            catch (MySqlException ex)
            {
                throw new Exception("Não foi possível conectar ao banco de dados.\n" + ex.Message);
            }
        }

        public void Executar(string sql)
        {
            Conectar();
            MySqlCommand comando = new MySqlCommand(sql, conexao);
            comando.ExecuteNonQuery();

        }

        public DataTable Consultar(string sql)
        {
            Conectar();
            MySqlDataAdapter dados = new MySqlDataAdapter(sql, conexao);
            DataTable dt = new DataTable();
            dados.Fill(dt);
            return dt;
        }
    }
}
