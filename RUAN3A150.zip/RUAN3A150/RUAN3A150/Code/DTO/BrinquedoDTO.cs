﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using RUAN3A150.Code.DTO;
using RUAN3A150.Code.BLL;
using RUAN3A150.Code.DAL;

namespace RUAN3A150.Code.DTO
{
    class BrinquedoDTO
    {
        private int _id;
        private string _nome;
        private double _valor;

        public int Id { get => _id; set => _id = value; }
        public string Nome { get => _nome; set => _nome = value; }
        public double Valor { get => _valor; set => _valor = value; }
    }
}

