﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RUAN3A150.Code.BLL;
using RUAN3A150.Code.DTO;

namespace RUAN3A150
{
    public partial class Form2 : Form
    {
        BrinquedoDTO brinquedoDTO = new BrinquedoDTO();
        BrinquedoBLL brinquedoBLL = new BrinquedoBLL();
        public Form2()
        {
            InitializeComponent();
        }

        private void button_inserir_Click(object sender, EventArgs e)
        {
            brinquedoDTO.Nome = input_nome.Text;
            brinquedoDTO.Valor = double.Parse(input_valor.Text);
            brinquedoBLL.Inserir(brinquedoDTO);
            MessageBox.Show("Brinquedo criado!");
            dataGridView1.DataSource = brinquedoBLL.Listar();
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            brinquedoDTO.Id = int.Parse(input_id.Text);
            brinquedoDTO.Nome = input_nome.Text;
            brinquedoDTO.Valor = double.Parse(input_valor.Text);
            brinquedoBLL.Alterar(brinquedoDTO);
            MessageBox.Show("Brinquedo alterado!");
            dataGridView1.DataSource = brinquedoBLL.Listar();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            brinquedoDTO.Id = int.Parse(input_id.Text);
            brinquedoBLL.Excluir(brinquedoDTO);
            MessageBox.Show("Brinquedo exluido!");
            dataGridView1.DataSource = brinquedoBLL.Listar();
        }

        private void button_listar_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = brinquedoBLL.Listar();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = brinquedoBLL.Listar();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            input_id.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            input_nome.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            input_valor.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
        }
    }
}
